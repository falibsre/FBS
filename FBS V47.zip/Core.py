from Classes.ServerConnection import ServerConnection

ServerConnection(("0.0.0.0", 9339))#9339 - port