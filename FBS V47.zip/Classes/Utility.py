class Utility:
    def parseFields(fields: dict):
        print()
        for typeName,value in fields.items():
            print(f"{typeName}: {value}")
        print()
