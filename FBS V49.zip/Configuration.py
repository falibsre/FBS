settings = {
    "DisableNagle": True,#Reduce delay and improve performance between client and server but require more power
    "PrintEnabled": True,
    "DumpMajor": 49
}