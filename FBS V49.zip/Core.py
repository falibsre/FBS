from Classes.ServerConnection import ServerConnection
import os
import Configuration

if not os.path.exists(f"HexDumpV{Configuration.settings['DumpMajor']}"):
    os.mkdir(f"HexDumpV{Configuration.settings['DumpMajor']}")

ServerConnection(("0.0.0.0", 9339))